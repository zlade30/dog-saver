Steps to run:
- Download node
- Go to vscode then Click ctrl + ~ to open command
- execute npm install
- execute npm start