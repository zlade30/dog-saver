export { default as AppRoutes } from './app-routes'
