export const publicRoutes = ['/login', '/register', '/overview']
