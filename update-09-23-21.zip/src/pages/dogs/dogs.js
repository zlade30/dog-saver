import React from 'react'

const Dogs = () => {
  return (
    <div className="container">
      Dogs
      <div className="home" />
    </div>
  )
}

export default Dogs
