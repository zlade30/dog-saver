import Dogs from './dogs'

export default Dogs
