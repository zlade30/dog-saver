import Announcements from './announcements'

export default Announcements
