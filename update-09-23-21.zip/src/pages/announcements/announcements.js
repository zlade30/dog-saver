import React from 'react'

const Announcements = () => {
  return (
    <div className="container">
      Announcements
      <div className="home" />
    </div>
  )
}

export default Announcements
