import Dashboard from './dashboard'

export default Dashboard
