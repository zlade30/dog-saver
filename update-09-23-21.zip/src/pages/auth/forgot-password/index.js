import ForgotPassword from './forgot-password'

export default ForgotPassword
